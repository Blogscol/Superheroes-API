<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://www.linkedin.com/in/miguel-mariano-developer/
 * @since      1.0.0
 *
 * @package    Superhero_Api
 * @subpackage Superhero_Api/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
